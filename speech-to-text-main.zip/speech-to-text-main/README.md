# speech-to-text
by using IBM watson we create speech to text using python 
